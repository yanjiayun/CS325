Step 1: python question2.py
Step 2: follow the instrustions and enter all needed elements.

Attention: Didn't handle bad input, so if you enter something wrong please go back to Step 1.
[Or you can change the data in main function instead of entering all the data one by one.]