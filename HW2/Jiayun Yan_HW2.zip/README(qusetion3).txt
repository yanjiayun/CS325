Step 1: python question3.py
Step 2: follow the instrustions and enter all needed elements.

Attention: Didn't handle bad input, so if you enter something wrong please go back to Step 1.
[Or you can delete the whole main function, use print(binarysearch(10,[[2, 3, 4],[5, 7, 9],[11, 12, 13],[20, 22, 24]])) instead.]